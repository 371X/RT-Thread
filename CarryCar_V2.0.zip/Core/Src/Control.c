/**
  ******************************************************************************
  * @file           : Control.c
  ******************************************************************************
  * @attention
  *�ļ������˿��Ƶ����С���ٶȣ�С�����Ʋ���ˢ�£�С��״̬���ƣ�������Ʋ���ˢ�µ�API��
  ******************************************************************************
  */
#include<Control.h>
#include<tim.h>
#include<config.h>
#include<usart.h>
#include<pid.h>
int Car_state[8]={1,1,1,99,1,1,1,70};
__IO uint8_t  Start_flag = 0;       // PID ��ʼ��־
uint32_t Motor1_Dir = CW;             // �������
uint32_t Motor2_Dir = CW;
uint32_t Motor3_Dir = CW;   
uint32_t Motor4_Dir = CW; 
#define WHEELSTOP 0;
#define WHEELFORWARD 1;
#define WHEELBACKWARD 2;
int16_t CAR_SPEED=100;
void SetMotorSpeed(int16_t Duty,uint8_t ch)
{
  __HAL_TIM_SetCompare(&htim1,ch,Duty);
}

/**
  * ��������: ���õ��ת������
  * ���뺯��: Dir,���ת������
  * �� �� ֵ: ��
  * ˵    ��: ��
  */
void SetMotorDir(int16_t Dir)
{
  if(Dir)
  {
    HAL_TIM_PWM_Start(&htim1,TIM_CHANNEL_1);
    HAL_TIMEx_PWMN_Stop(&htim1,TIM_CHANNEL_1);         // ֹͣ���
		rt_kprintf("1");
  }
  else
  {
    HAL_TIM_PWM_Stop(&htim1,TIM_CHANNEL_1);
    HAL_TIMEx_PWMN_Start(&htim1,TIM_CHANNEL_1);         // ֹͣ���
  }
}
void Car_temp_change(void)
{
				static uint16_t count=0;
				count=0;
				while(usart_nb_type.usart_recv_buffer[count]!='#'&&count<=usart_nb_type.usart_recv_len)
				{ 
					count++;
				}
				if(count<usart_nb_type.usart_recv_len)
				{
							Car_state[0]=usart_nb_type.usart_recv_buffer[count+1]-48;
							Car_state[1]=usart_nb_type.usart_recv_buffer[count+3]-48;
							Car_state[2]=usart_nb_type.usart_recv_buffer[count+5]-48;
							if(usart_nb_type.usart_recv_buffer[count+8]==44)
							{
								Car_state[3]=usart_nb_type.usart_recv_buffer[count+7]-48;
								Car_state[4]=usart_nb_type.usart_recv_buffer[count+9]-48;
								Car_state[5]=usart_nb_type.usart_recv_buffer[count+11]-48;
								Car_state[6]=usart_nb_type.usart_recv_buffer[count+13]-48;
								if(usart_nb_type.usart_recv_buffer[count+16]=='!')
									Car_state[7]=usart_nb_type.usart_recv_buffer[count+15]-48;
								else
									Car_state[7]=(usart_nb_type.usart_recv_buffer[count+15]-48)*10 + usart_nb_type.usart_recv_buffer[count+16]-48;
							}
							else
							{
								Car_state[3]=(usart_nb_type.usart_recv_buffer[count+7]-48)*10 + usart_nb_type.usart_recv_buffer[count+8]-48;
								Car_state[4]=usart_nb_type.usart_recv_buffer[count+10]-48;
								Car_state[5]=usart_nb_type.usart_recv_buffer[count+12]-48;
								Car_state[6]=usart_nb_type.usart_recv_buffer[count+14]-48;
								if(usart_nb_type.usart_recv_buffer[count+17]=='!')
									Car_state[7]=usart_nb_type.usart_recv_buffer[count+16]-48;
								else
									Car_state[7]=(usart_nb_type.usart_recv_buffer[count+16]-48)*10 + usart_nb_type.usart_recv_buffer[count+17]-48;
							}
				}
				count=0;

}

void Car_statecontrol(uint8_t ch)
{
	switch(ch)
	{
		case CAR_CMD_FORWARD:
			Car_speed_set(CAR_SPEED,CAR_SPEED,CAR_SPEED,CAR_SPEED);//С��ǰ��
		break;
		case CAR_CMD_BACK:
			Car_speed_set(-CAR_SPEED,-CAR_SPEED,-CAR_SPEED,-CAR_SPEED);//С������
		break;
		case CAR_CMD_LEFT:
		   Car_speed_set(-CAR_SPEED,CAR_SPEED,CAR_SPEED,-CAR_SPEED);//С����ƽ��
		break;
		case CAR_CMD_RIGHT:
			 Car_speed_set(CAR_SPEED,-CAR_SPEED,-CAR_SPEED,CAR_SPEED);//С����ƽ��
		break;
		case CAR_CMD_SPIN_LEFT:
			Car_speed_set(CAR_SPEED,-CAR_SPEED,CAR_SPEED,-CAR_SPEED);//С����ʱ����ת
		break;
		case CAR_CMD_SPIN_RIGHT:
			Car_speed_set(-CAR_SPEED,CAR_SPEED,-CAR_SPEED,CAR_SPEED);//С��˳ʱ����ת
		break;
		case CAR_CMD_FORWARD_LEFT:
			 Car_speed_set(0,CAR_SPEED,CAR_SPEED,0);//С������
		break;
		case CAR_CMD_FORWARD_RIGHT:
			Car_speed_set(CAR_SPEED,0,0,CAR_SPEED);//С������
		break;
		case CAR_CMD_BACK_RIGHT:
			Car_speed_set(0,-CAR_SPEED,-CAR_SPEED,0);//С������
		break;
		case CAR_CMD_BACK_LEFT:
			Car_speed_set(-CAR_SPEED,0,0,-CAR_SPEED);//С������
		break;
		case CAR_CMD_STOP:
			Car_speed_set(0,0,0,0);//С��ֹͣ
		break;
				
	}
}
void Car_speed_set(int16_t speed1,int16_t speed2,int16_t speed3,int16_t speed4)
{

		sPID.SetPoint[0] = speed1;     // �趨Ŀ��Desired Value
		sPID.SetPoint[1] = speed2;
		sPID.SetPoint[2] = speed3;
		sPID.SetPoint[3] = speed4;
}

void Car_statejuge()
	
{
/*************************************************************************/ //����С��״̬	
		if(Car_state[0]==2)
		{
			if(Car_state [1]==2)
				Car_statecontrol(CAR_CMD_FORWARD_LEFT); //��ʱС����״̬��ǰ
			else if(Car_state[1]==0)
				Car_statecontrol(CAR_CMD_BACK_LEFT);//��ʱС��״̬���
			else
				Car_statecontrol(CAR_CMD_LEFT);//��ʱС����
		}
		else if(Car_state[0]==0)
		{
			if(Car_state [1]==2)
				Car_statecontrol(CAR_CMD_FORWARD_RIGHT); //��ʱС����״̬��ǰ
			else if(Car_state[1]==0)
				Car_statecontrol(CAR_CMD_BACK_RIGHT);//��ʱС��״̬�Һ�
			else
				Car_statecontrol(CAR_CMD_RIGHT);//��ʱС����
		}
		else
		{
			if(Car_state [1]==2)
				Car_statecontrol(CAR_CMD_FORWARD);//��ʱС����ǰ
			else if(Car_state[1]==0)
				Car_statecontrol(CAR_CMD_BACK);//��ʱС�����
			else
			{
				 if(Car_state [2]==2)
					 Car_statecontrol(CAR_CMD_SPIN_RIGHT);//С��˳ʱ����ת
				 else if (Car_state [2]==0)
				   Car_statecontrol(CAR_CMD_SPIN_LEFT);//С����ʱ����ת
				 else
					 Car_statecontrol(CAR_CMD_STOP);
			}
		}
		if(Car_state[3]>80)
			Car_state[3]=80;
		else if(Car_state[3]<10)
			Car_state[3]=10;
		CAR_SPEED=-Car_state[3]+120;
/*************************************************************************/ //����С��״̬		

}
void Arm_statejuge()
{
	if(Car_state[4]==2)//����ת
		{
			if(arm_temp[0]<430)
				arm_temp[0]+=1;
		}
		else if(Car_state[4]==0)//����ת
		{
			if(arm_temp[0]>160)
				 arm_temp[0]-=1;
		}
		if(Car_state[5]==2)//����ת
		{
			if(arm_temp[1]>100)
				 arm_temp[1]-=1;
		}
		else if(Car_state[5]==0)//����ת
		{
			if(arm_temp[1]<240)
				arm_temp[1]+=1;
		}
		if(Car_state[6]==2)//����ת
		{
			if(arm_temp[2]<460)
				arm_temp[2]+=1;
		}
		else if(Car_state[6]==0)//����ת
		{
			if(arm_temp[2]>170)
				 arm_temp[2]-=1;
		}
		if(Car_state[7]>70)
			Car_state[7]=70;
		else if(Car_state[7]<10)
			Car_state[7]=10;
		arm_temp[3]=2*Car_state[7]+280;

}
	

