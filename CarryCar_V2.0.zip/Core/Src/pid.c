/**
  ******************************************************************************
  * @file           : pid.c
  ******************************************************************************
  * @attention
  *PID������ص�API,����pid����ʱ����λ��ͨ�ŵĺ���
  ******************************************************************************
  */

#include<pid.h>
#include<config.h>
#include<Control.h>
__IO int32_t Spd_Pulse[4];              // ����������ֵ Pulse
__IO int32_t LastSpd_Pulse[4];          // ����������ֵ Pulse
__IO int32_t Spd_PPS[4];                // �ٶ�ֵ Pulse/Sample
__IO float Spd_RPM[4];                  // �ٶ�ֵ r/m
__IO int32_t PWM_Duty[4]={0,0,0,0};

float warebuf[8] =  {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
PID_TypeDef  sPID;
void PID_ParamInit()
{
    sPID.LastError[0] = 0;               // Error[-1]
		sPID.LastError[1] = 0;               // Error[-1]
		sPID.LastError[2] = 0;               // Error[-1]
		sPID.LastError[3] = 0;               // Error[-1]
    sPID.PrevError[0] = 0;               // Error[-2
		sPID.PrevError[1] = 0;               // Error[-2]
		sPID.PrevError[2] = 0;               // Error[-2]
		sPID.PrevError[3] = 0;               // Error[-2]
    sPID.Proportion[0] = 4.0f; // �������� Proportional Const
    sPID.Integral[0] = 2.8f;   // ���ֳ���  Integral Const
    sPID.Derivative[0] = 0.15f; // ΢�ֳ��� Derivative Const
	  sPID.Proportion[1] = 4.0f; // �������� Proportional Const
    sPID.Integral[1] = 2.8f;   // ���ֳ���  Integral Const
    sPID.Derivative[1] = 0.13f; // ΢�ֳ��� Derivative Const
	  sPID.Proportion[2] = 4.0f; // �������� Proportional Const
    sPID.Integral[2] = 2.8f;   // ���ֳ���  Integral Const
    sPID.Derivative[2] = 0.12f; // ΢�ֳ��� Derivative Const
	  sPID.Proportion[3] = 4.0f; // �������� Proportional Const
    sPID.Integral[3] = 2.8f;   // ���ֳ���  Integral Const
    sPID.Derivative[3] = 0.13f ; // ΢�ֳ��� Derivative Const
    sPID.SetPoint[0] = TARGET_SPEED;     // �趨Ŀ��Desired Value
		sPID.SetPoint[1] = TARGET_SPEED;
		sPID.SetPoint[2] = TARGET_SPEED;
		sPID.SetPoint[3] = TARGET_SPEED;
}
int32_t SpdPIDCalc(float NextPoint,uint8_t value)
{
  float iError,iIncpid;
  iError = (float)sPID.SetPoint[value] - NextPoint; //ƫ��
  if((iError<0.2f )&& (iError>-0.2f))
    iError = 0.0f;

  iIncpid=(sPID.Proportion[value] * iError)                 //E[k]��
              -(sPID.Integral[value] * sPID.LastError[value])     //E[k-1]��
              +(sPID.Derivative[value] * sPID.PrevError[value]);  //E[k-2]��
  sPID.PrevError[value] = sPID.LastError[value];                    //�洢�������´μ���
  sPID.LastError[value] = iError;
  return(iIncpid);                                    //��������ֵ

}
void Encoderenable(void) //������ʹ��
{
	__HAL_TIM_CLEAR_IT(&htim2,TIM_IT_UPDATE);
	__HAL_TIM_CLEAR_IT(&htim3,TIM_IT_UPDATE);
	__HAL_TIM_CLEAR_IT(&htim4,TIM_IT_UPDATE);
	__HAL_TIM_CLEAR_IT(&htim5,TIM_IT_UPDATE);
//  /* ʹ�ܶ�ʱ���ĸ����¼��ж� */
	__HAL_TIM_ENABLE_IT(&htim2,TIM_IT_UPDATE);
	 __HAL_TIM_ENABLE_IT(&htim3,TIM_IT_UPDATE);
	 __HAL_TIM_ENABLE_IT(&htim4,TIM_IT_UPDATE);
	 __HAL_TIM_ENABLE_IT(&htim5,TIM_IT_UPDATE);
	/* ʹ�ܱ������ӿ� */
	//HAL_TIM_Base_Start_IT(&htim2);
		HAL_TIM_Encoder_Start(&htim2, TIM_CHANNEL_ALL);
	 HAL_TIM_Encoder_Start(&htim3, TIM_CHANNEL_ALL);
	 HAL_TIM_Encoder_Start(&htim4, TIM_CHANNEL_ALL);
	 HAL_TIM_Encoder_Start(&htim5, TIM_CHANNEL_ALL);
	__HAL_TIM_SET_COUNTER(&htim2,10000);
	__HAL_TIM_SET_COUNTER(&htim3,10000);
	__HAL_TIM_SET_COUNTER(&htim4,10000);
	__HAL_TIM_SET_COUNTER(&htim5,10000);
	
}
void PidSet(uint8_t ch) //PID���ƵĹؼ�����
{
		if(ch==TIM_CHANNEL_1 )
		{ 
			
			Spd_PPS[0]=10000-(int32_t)__HAL_TIM_GET_COUNTER(&htim2);
			__HAL_TIM_SET_COUNTER(&htim2,10000);
			Spd_RPM[0] = ((((float)Spd_PPS[0]/(float)1560)*50.0f)*(float)60);
			//rt_kprintf ("��������Ϊ%2000f\n",Spd_RPM[0]);
			//rt_kprintf("ƫ���СΪ%d\n",(float)sPID.SetPoint[0]-Spd_RPM[0]);
			
				if(Start_flag == 1)
			{
				PWM_Duty[0]+= SpdPIDCalc(Spd_RPM[0],0);
				if(PWM_Duty[0]>1200)
					PWM_Duty[0]=1199;
				else if(PWM_Duty[0]<-1200)
					PWM_Duty[0] =-1199;
//				  rt_kprintf("PWM_Duty��ֵ%d\n",PWM_Duty[0]);
				/* �жϵ�ǰ�˶����� */
				if(PWM_Duty[0] < 0)
				{
					Motor1_Dir = CW;
					BDDCMOTOR1_DIR_CW();
					SetMotorSpeed(-PWM_Duty[0],TIM_CHANNEL_1);
				}
				else
				{
					Motor1_Dir = CCW;
					BDDCMOTOR1_DIR_CCW();
					SetMotorSpeed(PWM_Duty[0],TIM_CHANNEL_1);
				}
			}
		
		}

		else if(ch==TIM_CHANNEL_2 )
		{ 
			
			Spd_PPS[1]=10000-(int32_t)__HAL_TIM_GET_COUNTER(&htim3);
			__HAL_TIM_SET_COUNTER(&htim3,10000);
//			rt_kprintf ("��������Ϊ%d",Spd_PPS[1]);
			/* 11�߱�����,270���ٱ�,һȦ�����ź���11*270*4 = 11880 */
			/* 11�߱�����,270���ٱ�,һȦ�����ź���11*270*4 = 11880 */
			Spd_RPM[1] = ((((float)Spd_PPS[1]/(float)1560)*50.0f)*(float)60);
			if(Start_flag == 1)
			{
				PWM_Duty[1]+= SpdPIDCalc(Spd_RPM[1],1);
				if(PWM_Duty[1]>1200)
					PWM_Duty[1]=1199;
				else if(PWM_Duty[1]<-1200)
					PWM_Duty[1] =-1199;
				 
				/* �жϵ�ǰ�˶����� */
				if(PWM_Duty[1] < 0)
				{
					Motor2_Dir = CW;
					BDDCMOTOR2_DIR_CW();
					SetMotorSpeed(-PWM_Duty[1],TIM_CHANNEL_2);
				}
				else
				{
					Motor2_Dir = CCW;
					BDDCMOTOR2_DIR_CCW();
					SetMotorSpeed(PWM_Duty[1],TIM_CHANNEL_2);
				}
			}
		}
		else if(ch==TIM_CHANNEL_3 )
		{ 
			 
			Spd_PPS[2]=10000-(int32_t)__HAL_TIM_GET_COUNTER(&htim4);
			__HAL_TIM_SET_COUNTER(&htim4,10000);
			Spd_RPM[2] = ((((float)Spd_PPS[2]/(float)1560)*50.0f)*(float)60);
			/* ����PID��� */
			if(Start_flag == 1)
			{
				PWM_Duty[2]+= SpdPIDCalc(Spd_RPM[2],2);
				if(PWM_Duty[2]>1200)
					PWM_Duty[2]=1199;
				else if(PWM_Duty[2]<-1200)
					PWM_Duty[2] =-1199;
//				 rt_kprintf("PWM_Duty��ֵ%d\n",PWM_Duty[2]);
				/* �жϵ�ǰ�˶����� */
				if(PWM_Duty[2] < 0) 
				{
					Motor3_Dir = CW;
					BDDCMOTOR3_DIR_CW();
					SetMotorSpeed(-PWM_Duty[2],TIM_CHANNEL_3);
				}
				else
				{
					Motor3_Dir = CCW;
					BDDCMOTOR3_DIR_CCW();
					SetMotorSpeed(PWM_Duty[2],TIM_CHANNEL_3);
				}
			}
		}
		else if(ch==TIM_CHANNEL_4 )
		{ 
			Spd_PPS[3]=10000-(int32_t)__HAL_TIM_GET_COUNTER(&htim5);
			__HAL_TIM_SET_COUNTER(&htim5,10000);
			//rt_kprintf ("��������Ϊ%d",Spd_PPS[3]);
			Spd_RPM[3] = ((((float)Spd_PPS[3]/(float)1560)*50.0f)*(float)60);
		/* ����PID��� */
			if(Start_flag == 1)
			{
				PWM_Duty[3]+= SpdPIDCalc(Spd_RPM[3],3);
				if(PWM_Duty[3]>1200)
					PWM_Duty[3]=1199;
				else if(PWM_Duty[3]<-1200)
					PWM_Duty[3] =-1199;
				 //rt_kprintf("PWM_Duty��ֵ%d\n",PWM_Duty[3]);
				/* �жϵ�ǰ�˶����� */
				if(PWM_Duty[3] < 0)
				{
					Motor4_Dir = CW;
					BDDCMOTOR4_DIR_CW();
					SetMotorSpeed(-PWM_Duty[3],TIM_CHANNEL_4);
				}
				else
				{
					Motor4_Dir = CCW;
					BDDCMOTOR4_DIR_CCW();
					SetMotorSpeed(PWM_Duty[3],TIM_CHANNEL_4);
				}
			}
	}
}
/*PID����ʱ����λ������ͨ�ŵĺ���*/
/*********************************************************/
void vcan_sendware(uint8_t *wareaddr, uint32_t waresize)
{ 
    uint8_t cmdf[2] = {0x03, 0xfc};
    uint8_t cmdr[2] = {0xfc, 0x03};
   
    usart1_putbuff(cmdf,sizeof(cmdf));
    usart1_putbuff(wareaddr,waresize);
    usart1_putbuff(cmdr,sizeof(cmdr));
}
void usart1_putbuff (uint8_t *buff, uint32_t len)
{
    while(len--)
    {
					HAL_UART_Transmit(&huart1, (uint8_t*)buff,1,100);
          buff++;
    }
}
/*********************************************************/
