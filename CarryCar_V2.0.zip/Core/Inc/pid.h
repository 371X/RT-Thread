#ifndef __PID_H__
#define __PID_H__
#include<stm32g4xx.h>

typedef struct
{
  __IO int32_t  SetPoint[4];                                 //�趨Ŀ�� Desired Value
  __IO float     SumError[4];                                //����ۼ�
  __IO float    Proportion[4];                               //�������� Proportional Const
  __IO float    Integral[4];                                 //���ֳ��� Integral Const
  __IO float    Derivative[4];                               //΢�ֳ��� Derivative Const
  __IO int      LastError[4];                                //Error[-1]
  __IO int      PrevError[4];                                //Error[-2]
}PID_TypeDef;

#define  TARGET_SPEED    0.0f       // Ŀ���ٶ�    10r/m
__IO extern int32_t Spd_Pulse[4];              // ����������ֵ Pulse
__IO extern int32_t LastSpd_Pulse[4];          // ����������ֵ Pulse
__IO extern int32_t Spd_PPS[4];                // �ٶ�ֵ Pulse/Sample
__IO extern float Spd_RPM[4];                  // �ٶ�ֵ r/m
__IO extern int32_t OverflowCount[4];
__IO extern int32_t PWM_Duty[4];
extern float warebuf[8];
extern PID_TypeDef  sPID;
void PID_ParamInit(void) ;
int32_t SpdPIDCalc(float NextPoint,uint8_t value);
void Encoderenable(void);
void PidSet(uint8_t ch);
void Calspeed(uint16_t ch);
void vcan_sendware(uint8_t *wareaddr, uint32_t waresize);
void usart1_putbuff (uint8_t *buff, uint32_t len);
#endif
