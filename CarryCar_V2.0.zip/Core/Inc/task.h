#ifndef _TASK_H_
#define _TASK_H_

void TaskInit(void);
void car_thread_entry(void *parameter);
#endif
