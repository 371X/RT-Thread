#ifndef __PCA9685_H__
#define __PCA9685_H__

#define HI2C hi2c1
#include "main.h"

#include "i2c.h"
#define PCA9685_adrr 0x80

#define PCA9685_SUBADR1 0x2
#define PCA9685_SUBADR2 0x3
#define PCA9685_SUBADR3 0x4

#define PCA9685_MODE1 0x0
#define PCA9685_PRESCALE 0xFE

#define LED0_ON_L 0x6
#define LED0_ON_H 0x7
#define LED0_OFF_L 0x8
#define LED0_OFF_H 0x9

#define ALLLED_ON_L 0xFA
#define ALLLED_ON_H 0xFB
#define ALLLED_OFF_L 0xFC
#define ALLLED_OFF_H 0xFD
extern uint32_t arm_temp[4];
void PCA9685_Reset(void);
void SetPWMFreq(float freq);
void SetPWM(uint32_t num,uint32_t on,uint32_t off);
uint8_t PCA9685_read(uint8_t startAddress);
void PCA9685_write(uint8_t startAddress, uint8_t buffer);

#endif

