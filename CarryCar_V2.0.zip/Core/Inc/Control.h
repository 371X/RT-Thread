#ifndef __CONTROL_H__
#define __CONTROL_H__
#include "stm32g4xx_hal.h"
__IO extern uint8_t  Start_flag;       // PID ��ʼ��־
void get_char_return_int(int * dmp, char * buf);
extern uint32_t Motor1_Dir;             // �������
extern uint32_t Motor2_Dir;
extern uint32_t Motor3_Dir;
extern uint32_t Motor4_Dir;
enum car_cmd
{
		
    CAR_CMD_FORWARD,            /* ǰ�� */
    CAR_CMD_BACK,               /* ���� */
	  CAR_CMD_LEFT,               /* ��ƽ�� */
    CAR_CMD_RIGHT,              /* ��ƽ�� */
		CAR_CMD_SPIN_LEFT,					/*��ʱ����ת*/
		CAR_CMD_SPIN_RIGHT,					/*˳ʱ����ת*/
    CAR_CMD_FORWARD_LEFT,       /* ǰ�� */
    CAR_CMD_FORWARD_RIGHT,      /* ǰ�� */
    CAR_CMD_BACK_LEFT,          /* ���� */
    CAR_CMD_BACK_RIGHT,         /* ���� */
		CAR_CMD_STOP               /* ֹͣ */
};
#define CW                                   1
#define CCW                                  0
#define BDDCMOTOR1_DIR_CW()                      {HAL_TIM_PWM_Stop(&htim1,TIM_CHANNEL_1);\
                                              HAL_TIMEx_PWMN_Start(&htim1,TIM_CHANNEL_1);}
#define BDDCMOTOR1_DIR_CCW()                     {HAL_TIM_PWM_Start(&htim1,TIM_CHANNEL_1);\
                                              HAL_TIMEx_PWMN_Stop(&htim1,TIM_CHANNEL_1);}
#define BDDCMOTOR2_DIR_CW()                      {HAL_TIM_PWM_Stop(&htim1,TIM_CHANNEL_2);\
                                              HAL_TIMEx_PWMN_Start(&htim1,TIM_CHANNEL_2);}
#define BDDCMOTOR2_DIR_CCW()                     {HAL_TIM_PWM_Start(&htim1,TIM_CHANNEL_2);\
                                              HAL_TIMEx_PWMN_Stop(&htim1,TIM_CHANNEL_2);}
#define BDDCMOTOR3_DIR_CW()                      {HAL_TIM_PWM_Stop(&htim1,TIM_CHANNEL_3);\
                                              HAL_TIMEx_PWMN_Start(&htim1,TIM_CHANNEL_3);}
#define BDDCMOTOR3_DIR_CCW()                     {HAL_TIM_PWM_Start(&htim1,TIM_CHANNEL_3);\
                                              HAL_TIMEx_PWMN_Stop(&htim1,TIM_CHANNEL_3);}
#define BDDCMOTOR4_DIR_CW()                      {HAL_TIM_PWM_Stop(&htim1,TIM_CHANNEL_4);\
                                              HAL_TIMEx_PWMN_Start(&htim1,TIM_CHANNEL_4);}
#define BDDCMOTOR4_DIR_CCW()                     {HAL_TIM_PWM_Start(&htim1,TIM_CHANNEL_4);\
                                              HAL_TIMEx_PWMN_Stop(&htim1,TIM_CHANNEL_4);}
extern int16_t CAR_SPEED ;
void SeMotorSpeed(int16_t Duty,uint8_t ch);
void SetMotorDir(int16_t Dirt);
void Car_statecontrol(uint8_t ch);
extern int Car_state[8];
void Car_speed_set(int16_t speed1,int16_t speed2,int16_t speed3,int16_t speed4);
void  Car_temp_change(void);
void get_char_return_int(int * dmp, char * buf);
void Car_statejuge(void);
void Arm_statejuge(void);
#endif

